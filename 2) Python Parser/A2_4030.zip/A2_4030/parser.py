from lexer import CICOMLexer as lexer
import ply.yacc as yacc

tokens = lexer.tokens
lexer = lexer().buildLexer()

def p_Exp(p):
    """
    Exp : Term
    | Term PLUS Exp
    | Term MINUS Exp
    | Term OPERATOR Exp
    | IF Exp THEN Exp ELSE Exp
    | LET DefList IN Exp
    | MAP IdList TO Exp
    | MAP TO Exp
    """
    pass

def p_Term(p):
    """
    Term : PLUS Term
    | MINUS Term
    | TILDE Term
    | Factor LPAREN ExpList RPAREN
    | Factor LPAREN  RPAREN
    | Factor
    | Empty
    | INT
    | Bool
    """
    pass

def p_Factor(p):
    """
    Factor : LPAREN Exp RPAREN
    | Prim
    | Id
    """
    pass

def p_ExpList(p):
    """
    ExpList : PropExpList
    """
    pass

def p_PropExpList(p):
    """
    PropExpList : Exp
    | Exp COMMA PropExpList
    """
    pass

def p_IdList(p):
    """
    IdList : PropIdList
    """

def p_PropIdList(p):
    """
    PropIdList : Id
    | Id COMMA PropIdList
    """
    pass

def p_DefList(p):
    """
    DefList : Def DefList
    | Def
    """
    pass

def p_Def(p):
    """
    Def : Id ASSIGN Exp SEMICOLON
    """
    pass

def p_Empty(p):
    """
    Empty : EMPTY
    """
    pass

def p_Bool(p):
    """
    Bool : TRUE
    | FALSE
    """
    pass


def p_Prim(p):
    """
     Prim : NUMBER_1
         | FUNCTION_1
         | LIST_1
         | EMPTY_1
         | CONS_1
         | CONS
         | FIRST
         | REST
         | ARITY
    """
    pass

def p_error(p):
    print("Syntax error at token", p, "line:", p.lexer.lineno)


parser = yacc.yacc()
