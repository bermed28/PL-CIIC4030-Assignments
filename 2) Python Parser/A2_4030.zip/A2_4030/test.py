from lexer import CICOMLexer
import os

_CUR_DIR = os.curdir

def test_lexer():
    with open(os.path.join(_CUR_DIR,"Test.txt"), 'r') as testDoc:
        string = testDoc.read()
        lexer = CICOMLexer().buildLexer()
        lexer.input(string)

    tokens = []

    while True:
        token = lexer.token()
        if not token:
            break
        tokens.append(token)

    return tokens