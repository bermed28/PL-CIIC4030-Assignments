import ply.lex as lex
from ply.lex import TOKEN


class CICOMLexer():

    keywords = {
        "if": "IF",
        "else": "ELSE",
        "then": "THEN",
        "to": "TO",
        "map": "MAP",
        "in": "IN",
        "let": "LET",
        "true": "TRUE",
        "false": "FALSE",
        "empty": "EMPTY",
        "number?": "NUMBER_1",
        "function?": "FUNCTION_1",
        "list?": "LIST_1",
        "empty?": "EMPTY_1",
        "cons?": "CONS_1",
        "cons": "CONS",
        "first": "FIRST",
        "rest": "REST",
        "arity": "ARITY"
    }

    tokens = (""
        'PLUS', 'MINUS', 'LPAREN',
        'RPAREN', 'INT', 'LBRACKET', 'RBRACKET',
        'OPERATOR', 'ASSIGN', 'COMMA',  'Id', 'TILDE',
        'SEMICOLON',
    ) + tuple(keywords.values())

    def t_newline(self,t):
        r'\n+'
        t.lexer.lineno += len(t.value)

    t_OPERATOR = r"(\*|\/|\=|\!=|\<=|\>=|\<|\>|\&)"
    t_TILDE = r"\~"

    t_PLUS = r'\+'
    t_MINUS = r'-'
    t_LPAREN = r'\('
    t_RPAREN = r'\)'
    t_LBRACKET = r'\['
    t_RBRACKET = r'\]'
    t_COMMA = r'\,'
    t_ASSIGN = r'\:='
    t_SEMICOLON = r'\;'

    char = r"([a-zA-Z]|\?|_)"
    digit = r"[0-9]"

    t_INT = digit + r"+"

    # A string containing ignored characters (spaces and tabs)
    t_ignore = ' | \t'

    identifier = rf'{char} ({char}|{digit})*'



    @TOKEN(identifier)
    def t_Id(self, t):
        t.type = self.keywords.get(t.value, "Id")
        return t

    def t_error(self,t):
        print("Illegal character '%s'" % t.value[0])
        t.lexer.skip(1)

    def buildLexer(self):
        return lex.lex(module=self)